import os
import shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.dirname(__file__))
PKG = os.path.join(BASE, 'collab_package')
SRC_LIB = os.path.join(BASE, '..', 'src', 'datacollapse', 'datacollapse.py')
DATA_SRC = os.path.join(BASE, 'real_data_combined.csv')

# 确保目标目录存在
os.makedirs(PKG, exist_ok=True)

# 最新推荐参数（基于 FINAL_SYNTHESIS_REPORT.md）
NOFSE_UC = 8.669546
NOFSE_A  = 1.191639
NOFSE_UC_ERR = 0.002214
NOFSE_A_ERR  = 0.011695

FSE_UC = 8.448503
FSE_A  = 1.285148
FSE_UC_ERR = 0.074273
FSE_A_ERR  = 0.065871
# FSE的(b,c)采用广义bootstrap的中位数（作为回退绘图用；默认优先Top-Q）
FSE_B = 0.7977894766363625
FSE_C = -1.0630991340121303


def ensure_dir(p):
	os.makedirs(p, exist_ok=True)


def load_data():
	df = pd.read_csv(DATA_SRC)
	return df


def get_L_colors(df):
	Ls = sorted(df['L'].unique().tolist())
	cmap = plt.cm.get_cmap('tab10', max(10, len(Ls)))
	colors = [cmap(i % 10) for i in range(len(Ls))]
	return {int(L): colors[i] for i, L in enumerate(Ls)}


def plot_raw(df, out_png, L_colors):
	plt.figure(figsize=(6,4))
	for L, d in df.groupby('L'):
		c = L_colors[int(L)]
		plt.errorbar(d['U'], d['Y'], yerr=d['sigma'], fmt='o-', ms=3, lw=1, alpha=0.8, color=c, label=f'L={int(L)}')
	plt.xlabel('U')
	plt.ylabel(r'$R_{{01}}$')
	plt.title('Raw data')
	plt.legend(ncol=2, fontsize=8)
	plt.tight_layout()
	plt.savefig(out_png, dpi=220)
	plt.close()


def plot_nofse_collapse(df, out_png, L_colors):
	df2 = df[df['L']!=7].copy()
	x = (df2['U'] - NOFSE_UC) * (df2['L']**NOFSE_A)
	plt.figure(figsize=(6,4))
	for L, d in df2.assign(x=x).groupby('L'):
		c = L_colors[int(L)]
		plt.errorbar(d['x'], d['Y'], yerr=d['sigma'], fmt='o', ms=3, alpha=0.8, color=c, label=f'L={int(L)}')
	plt.xlabel(r'$x=(U-U_c)\,L^{\,1/\nu}$')
	plt.ylabel(r'$R_{{01}}$')
	plt.title('Data collapse (drop L=7)')
	plt.legend(ncol=2, fontsize=8)
	plt.tight_layout()
	plt.savefig(out_png, dpi=220)
	plt.close()


def pick_fse_top_params():
	csv_path = os.path.join(BASE, 'generalized_bootstrap_fse_allL.csv')
	try:
		df = pd.read_csv(csv_path)
		if len(df)==0:
			return None
		idx = int(np.argmax(df['Q'].to_numpy()))
		row = df.iloc[idx]
		return float(row['Uc']), float(row['a']), float(row['b']), float(row['c'])
	except Exception:
		return None


def plot_fse_collapse(df, out_png, L_colors):
	# Top-Q参数优先（与核心图一致），否则回退到推荐中位数
	pick = pick_fse_top_params()
	if pick is not None:
		Uc_plot, a_plot, b_plot, c_plot = pick
	else:
		Uc_plot, a_plot, b_plot, c_plot = FSE_UC, FSE_A, FSE_B, FSE_C
	# 使用规范化因子（normalize=geom）
	L_vals = df['L'].to_numpy(float)
	L_ref = float(np.exp(np.mean(np.log(L_vals))))
	s = 1.0 + b_plot * (L_vals**c_plot)
	s_ref = 1.0 + b_plot * (L_ref**c_plot)
	s_norm = s / s_ref
	Yc = df['Y'] / s_norm
	sigc = df['sigma'] / s_norm
	x = (df['U'] - Uc_plot) * (df['L']**a_plot)
	plt.figure(figsize=(6,4))
	for L, d in df.assign(x=x, Yc=Yc, sigc=sigc).groupby('L'):
		c = L_colors[int(L)]
		plt.errorbar(d['x'], d['Yc'], yerr=d['sigc'], fmt='o', ms=3, alpha=0.8, color=c, label=f'L={int(L)}')
	plt.xlabel(r'$x=(U-U_c)\,L^{\,1/\nu}$')
	plt.ylabel(r'$R_{{01}}$')
	plt.title('Data collapse (all L, with finite size correction)')
	plt.legend(ncol=2, fontsize=8)
	plt.tight_layout()
	plt.savefig(out_png, dpi=220)
	plt.close()


def write_readme(path_md):
	txt = []
	txt.append('# Data collapse summary (for collaborators)\n')
	txt.append('\n')
	txt.append('## Data input\n')
	txt.append('- Please place your raw data under a directory named `Data_scale/`.\n')
	txt.append('- The script will scan files, infer L from filenames or parent folders (e.g., `L=9_*.csv`, `.../L=11/data.csv`).\n')
	txt.append('- Each file should provide columns like: `U, R01, sigma` (or `U, Y, sigma`). Column names are auto-mapped.\n')
	txt.append('\n')
	txt.append('## Ansatz\n')
	txt.append('- Data collapse (drop L=7):  Y ≈ f((U − U_c) L^{1/ν})\n')
	txt.append('- Data collapse (all L, with finite size correction):  Y ≈ f((U − U_c) L^{1/ν}) × (1 + b L^c)\n')
	txt.append('- Plotting for finite-size correction: normalized by s_norm=(1+b L^c)/(1+b L_ref^c), L_ref=geom mean\n')
	txt.append('\n')
	txt.append('## Recommended parameters (median ± uncertainty)\n')
	txt.append(f'- Data collapse (drop L=7):  U_c = {NOFSE_UC:.6f} ± {NOFSE_UC_ERR:.6f},   ν^(-1) = {NOFSE_A:.6f} ± {NOFSE_A_ERR:.6f}\n')
	txt.append(f'- Data collapse (all L, with finite size correction):  U_c = {FSE_UC:.6f} ± {FSE_UC_ERR:.6f},   ν^(-1) = {FSE_A:.6f} ± {FSE_A_ERR:.6f}\n')
	txt.append(f'- (b,c) plotting medians: ({FSE_B:.6f}, {FSE_C:.6f})\n')
	txt.append('\n')
	txt.append('## One-click reproduce (fit + plots)\n')
	txt.append('1. pip install -r requirements.txt\n')
	txt.append('2. python reproduce_three_plots.py --data-scale Data_scale\n')
	txt.append('   - The script will: build `real_data_combined.csv` from Data_scale → fit via datacollapse → generate three figures.\n')
	txt.append('   - Update `Data_scale/` (e.g., add new L), then re-run to refresh all results.\n')
	with open(path_md, 'w', encoding='utf-8') as f:
		f.write(''.join(txt))


def write_requirements(path_txt):
	with open(path_txt, 'w', encoding='utf-8') as f:
		f.write('\n'.join([
			'numpy', 'pandas', 'matplotlib'
		]))


def write_reproduce_script(path_py):
	code = """
import os, sys, re, glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import argparse

# local datacollapse
sys.path.insert(0, '.')
from datacollapse.datacollapse import fit_data_collapse, fit_data_collapse_fse_robust, collapse_transform

plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def build_combined_from_datascale(data_scale_dir: str, out_csv: str) -> pd.DataFrame:
    rows = []
    # scan files
    patterns = ['**/*.csv', '**/*.txt']
    files = []
    for p in patterns:
        files.extend(glob.glob(os.path.join(data_scale_dir, p), recursive=True))
    def infer_L(path):
        # try L=xx in filename or parent dirs
        m = re.search(r'L\s*=\s*(\d+)', path)
        if m: return int(m.group(1))
        parts = os.path.normpath(path).split(os.sep)
        for seg in parts[::-1]:
            m = re.search(r'L\s*=\s*(\d+)', seg)
            if m: return int(m.group(1))
        # fallback: try _Lxx
        m = re.search(r'_L(\d+)', path)
        if m: return int(m.group(1))
        return None
    def read_table(p):
        try:
            df = pd.read_csv(p)
        except Exception:
            df = pd.read_csv(p, sep='\s+', engine='python')
        return df
    def map_columns(df):
        cols = {c.lower(): c for c in df.columns}
        u = cols.get('u')
        y = cols.get('r01') or cols.get('y') or cols.get('r_01')
        s = cols.get('sigma') or cols.get('err') or cols.get('error')
        if not (u and y):
            raise ValueError('Missing U or Y (R01) columns')
        if s is None:
            # approximate sigma if absent
            s = y
            df[s] = np.std(df[y]) * 0.05
        return df[[u, y, s]].rename(columns={u:'U', y:'Y', s:'sigma'})
    for fp in files:
        L = infer_L(fp)
        if L is None: 
            continue
        try:
            d = read_table(fp)
            d = map_columns(d)
            d['L'] = int(L)
            rows.append(d[['L','U','Y','sigma']])
        except Exception:
            continue
    if not rows:
        raise RuntimeError('No usable files found under Data_scale/. Expect files with columns U,Y(R01),sigma and L hinted by filenames/folders.')
    df = pd.concat(rows, ignore_index=True)
    # optional cleaning/sorting
    df = df.sort_values(['L','U']).reset_index(drop=True)
    df.to_csv(out_csv, index=False)
    return df


def load_or_build_combined(data_scale_dir: str, out_csv: str) -> pd.DataFrame:
    if os.path.exists(out_csv):
        return pd.read_csv(out_csv)
    if not os.path.isdir(data_scale_dir):
        raise FileNotFoundError(f'Data_scale directory not found: {data_scale_dir}')
    return build_combined_from_datascale(data_scale_dir, out_csv)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data-scale', type=str, default='Data_scale')
    args = ap.parse_args()

    # build combined CSV
    combined_csv = 'real_data_combined.csv'
    df = load_or_build_combined(args.data_scale, combined_csv)

    # unified colors
    Ls = sorted(df['L'].unique().tolist())
    cmap = plt.get_cmap('tab10', max(10, len(Ls)))
    L_colors = {int(Lv): cmap(i % 10) for i, Lv in enumerate(Ls)}

    # Raw
    plt.figure(figsize=(6,4))
    for Lv, d in df.groupby('L'):
        c = L_colors[int(Lv)]
        plt.errorbar(d['U'], d['Y'], yerr=d['sigma'], fmt='o-', ms=3, lw=1, alpha=0.9, color=c, label=f'L={int(Lv)}')
    plt.xlabel('U'); plt.ylabel(r'$R_{01}$'); plt.title('Raw data'); plt.legend(ncol=2, fontsize=8)
    plt.tight_layout(); plt.savefig('collab_raw.png', dpi=220); plt.close()

    # Data collapse (drop L=7): fit
    DF2 = df[df['L']!=7].copy().reset_index(drop=True)
    data2 = DF2[['L','U','Y']].to_numpy(float)
    sigma2 = DF2['sigma'].to_numpy(float)
    bounds = ((8.0, 9.0), (0.6, 2.0))
    Uc0, a0 = 8.67, 1.20
    (params2, errs2) = fit_data_collapse(data2, sigma2, Uc0, a0, n_knots=10, lam=1e-3,
                                         n_boot=50, random_state=0, bounds=bounds,
                                         optimizer='NM_then_Powell', maxiter=4000, random_restarts=8)
    xC2, YC2 = collapse_transform(data2, params2)
    plt.figure(figsize=(6,4))
    for Lv, g in DF2.assign(x=xC2, Yc=YC2).groupby('L'):
        c = L_colors[int(Lv)]
        plt.errorbar(g['x'], g['Yc'], yerr=g['sigma'], fmt='o', ms=3, alpha=0.9, color=c, label=f'L={int(Lv)}')
    plt.xlabel(r'$x=(U-U_c)\\,L^{\\,1/\\nu}$'); plt.ylabel(r'$R_{01}$')
    plt.title('Data collapse (drop L=7)')
    _txt2 = "U_c="+str(round(params2[0],6))+"±"+str(round(errs2[0],6))+"\nν^(-1)="+str(round(params2[1],6))+"±"+str(round(errs2[1],6))
    plt.text(0.02, 0.98, _txt2, transform=plt.gca().transAxes,
             va='top', ha='left', fontsize=9, bbox=dict(boxstyle='round', fc='white', ec='gray', alpha=0.8))
    plt.tight_layout(); plt.savefig('collab_nofse_dropL7.png', dpi=220); plt.close()

    # Data collapse (all L, with finite size correction): robust fit
    DATA = df[['L','U','Y']].to_numpy(float)
    sigma = df['sigma'].to_numpy(float)
    b0 = 0.8; c0 = -1.0
    b_grid = np.linspace(b0-0.3, b0+0.3, 7)
    c_grid = np.linspace(c0-0.3, c0+0.3, 7)
    (params4, errs4) = fit_data_collapse_fse_robust(DATA, sigma, 8.45, 1.20,
                                                    b_grid=b_grid, c_grid=c_grid,
                                                    n_knots=10, lam=1e-3, n_boot=8, random_state=0,
                                                    bounds_Ua=((8.0, 9.0), (0.8, 2.0)),
                                                    normalize=True,
                                                    optimizer='NM_then_Powell', maxiter=4000, random_restarts=2)
    xC4, YC4 = collapse_transform(DATA, params4, normalize=True)
    plt.figure(figsize=(6,4))
    for Lv, g in df.assign(x=xC4, Yc=YC4).groupby('L'):
        c = L_colors[int(Lv)]
        plt.errorbar(g['x'], g['Yc'], yerr=g['sigma'], fmt='o', ms=3, alpha=0.9, color=c, label=f'L={int(Lv)}')
    plt.xlabel(r'$x=(U-U_c)\\,L^{\\,1/\\nu}$'); plt.ylabel(r'$R_{01}$')
    plt.title('Data collapse (all L, with finite size correction)')
    _txt4 = "U_c="+str(round(params4[0],6))+"±"+str(round(errs4[0],6))+"\nν^(-1)="+str(round(params4[1],6))+"±"+str(round(errs4[1],6))+"\n(b,c)=("+str(round(params4[2],6))+","+str(round(params4[3],6))+")"
    plt.text(0.02, 0.98, _txt4, transform=plt.gca().transAxes,
             va='top', ha='left', fontsize=9, bbox=dict(boxstyle='round', fc='white', ec='gray', alpha=0.8))
    plt.tight_layout(); plt.savefig('collab_fse_allL.png', dpi=220); plt.close()

    print('Done. Figures and parameter annotations saved. Combined CSV at:', combined_csv)

if __name__ == '__main__':
    main()
"""
	with open(path_py, 'w', encoding='utf-8') as f:
		f.write(code)


def main():
	# 清理包内多余旧文件
	for fname in ['collab_raw.png','collab_nofse_dropL7.png','collab_fse_allL.png','collab_note.md']:
		fp = os.path.join(PKG, fname)
		try:
			os.remove(fp)
		except FileNotFoundError:
			pass

	# 仅复制库代码（不复制real_data_combined.csv，改由脚本生成）
	dst_lib_dir = os.path.join(PKG, 'datacollapse')
	ensure_dir(dst_lib_dir)
	shutil.copy2(SRC_LIB, os.path.join(dst_lib_dir, 'datacollapse.py'))

	# 写README、复现脚本、依赖
	write_readme(os.path.join(PKG, 'README_collab.md'))
	write_reproduce_script(os.path.join(PKG, 'reproduce_three_plots.py'))
	write_requirements(os.path.join(PKG, 'requirements.txt'))

	# zip
	root = os.path.dirname(PKG)
	out_zip = os.path.join(root, 'collab_package')
	shutil.make_archive(out_zip, 'zip', PKG)
	print('Package created:', out_zip + '.zip')

if __name__ == '__main__':
	main() 